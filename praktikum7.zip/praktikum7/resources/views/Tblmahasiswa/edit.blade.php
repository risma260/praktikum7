@extends('layouts.main')

@section('content')
    <div class="container">
        <h1>Edit Data</h1>

        <form action="/Tblmahasiswa/{{$Tblmahasiswa->id}}" method="POST">
            @method('PUT')
            @csrf
            <div class="mb-3">
                <label class="form-label">NRP</label>
                <input type="text" name="nrp" class="form-control" value="{{$Tblmahasiswa->nrp}}">
              </div>
              <div class="mb-3">
                <label class="form-label">Nama</label>
                <input type="text" name="nama" class="form-control" value="{{$Tblmahasiswa->nama}}">
              </div>
              <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="text" name="email" class="form-control" value="{{$Tblmahasiswa->email}}">
              </div>
              <div class="mb-3">
                <label class="form-label">Alamat</label>
                <input type="text" name="alamat" class="form-control" value="{{$Tblmahasiswa->alamat}}">
              </div>
              <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
    
@endsection