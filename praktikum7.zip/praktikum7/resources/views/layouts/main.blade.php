<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
    <title>{{$title}}</title>
</head>
<body>
    <nav class="navbar justify-content-center navbar-expand-lg fixed-top" style="background-color: #e3f2fd;">
        <div class="container-fluid">
          <a class="navbar-brand" >Praktikum PAW</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav justify-content-center flex-wrap">
              <li class="nav-item">
                <a class="nav-link {{$title === 'index' ? 'active' : ''}}" href="/Tblmahasiswa/index">Data Mahasiswa</a>
              </li>
              <li class="nav-item">
                <a class="nav-link {{$title === 'tambah' ? 'active' : ''}}" href="/Tblmahasiswa/tambah">Input Data</a>
              </li>
              <li class="nav-item">
                <a class="nav-link {{$title === 'about' ? 'active' : ''}}" href="/Tblmahasiswa/about">About Me</a>
              </li>
            </ul>
          </div>
        </div>
    </nav>   

@yield('content')

  <!-- Footer -->
  <footer class="text-center text-lg-start bg-info text-muted">


    <!-- Section: Links  -->
    <section class="">
      <div class="container text-center text-md-start mt-5">
        <!-- Grid row -->
        <div class="row mt-3">
          <!-- Grid column -->
          <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
            <!-- Content -->
            <img src="https://kompaspedia.kompas.id/wp-content/uploads/2020/08/logo_Universitas-Trunojoyo-Madura-thumb.png" alt="utm" width="150px" >
            <p><b>Jurusan Teknik Informatika
            Universitas Trunojoyo Madura
            Jl.Raya Telang, Kecamatan Kamal,</b> Bangkalan
            69162 Indonesia
            Kampus Universitas Trunojoyo Madura
            </p>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
            <!-- Links -->
            <h6 class="text-uppercase fw-bold mb-4">
              Contact
            </h6>
            <p>
              Telp:031-3011146
            </p>
            <p>
              Fax:031-3011506
            </p>
            <p>
              email:if.ft@trunojoyo.ac.id
            </p>
            <p>
              
            </p>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
            <!-- Links -->
            <h6 class="text-uppercase fw-bold mb-4">
              Layanan
            </h6>
            <p>
              Pembayaran UKT
            </p>
            <p>
              Pembayaran KP
            </p>
            <p>
              Pendaftaran Wisuda
            </p>
            <p>
              Administrasi
            </p>
          </div>
          <!-- Grid column -->

          <!-- Grid column -->
          <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
            <!-- Links -->
            <h6 class="text-uppercase fw-bold mb-4">Resources</h6>
            <p><i class="fas fa-home me-3 text-secondary"></i>e-Journal</p>
            <p>
              <i class="fas fa-envelope me-3 text-secondary"></i>
              Portal Tugas Akhir
            </p>
            <p><i class="fas fa-phone me-3 text-secondary"></i>Website Resmi Kampus</p>
            <p><i class="fas fa-print me-3 text-secondary"></i>Download Administrasi</p>
          </div>
          <!-- Grid column -->
        </div>
        <!-- Grid row -->
      </div>
    </section>
    <!-- Section: Links  -->
  </footer>
  <!-- Footer -->
</body>
</html>