<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\TblmahasiswaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/Tblmahasiswa/index',[TblmahasiswaController::class,'index']);
Route::get('/Tblmahasiswa/tambah',[TblmahasiswaController::class,'tambah']);
Route::get('/Tblmahasiswa/hasil',[TblmahasiswaController::class,'hasil']);
Route::get('/Tblmahasiswa/{id}/edit',[TblmahasiswaController::class,'edit']);
Route::put('/Tblmahasiswa/{id}',[TblmahasiswaController::class,'update']);
Route::delete('/Tblmahasiswa/{id}',[TblmahasiswaController::class,'deletes']);
Route::get('/Tblmahasiswa/about',[TblmahasiswaController::class,'about']);