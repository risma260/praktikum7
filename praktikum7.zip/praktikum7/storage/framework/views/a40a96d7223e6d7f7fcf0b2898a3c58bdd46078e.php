

<?php $__env->startSection('content'); ?>
<h1>Data Mahasiswa</h1>
    <div class="container">
        <table class="table table-primary table-striped-columns">
            <tr>
                <td>ID</td>
                <td>NRP</td>
                <td>NAMA</td>
                <td>EMAIL</td>
                <td>ALAMAT</td>
                <td>Action</td>
            </tr>
            <?php $__currentLoopData = $Tblmahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <tr>
                <td><?php echo e($t->id); ?></td>
                <td><?php echo e($t->nrp); ?></td>
                <td><?php echo e($t->nama); ?></td>
                <td><?php echo e($t->email); ?></td>
                <td><?php echo e($t->alamat); ?></td>
                <td>
                    <a ref="/Tblmahasiswa/<?php echo e($t->id); ?>/edit" class="btn btn-info">Edit</a>
                    <form action="/Tblmahasiswa/<?php echo e($t->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <input type="submit" value="Delete" class="btn btn-secondary">
                    </form>
                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Risma\OneDrive\Dokumen\Semester 3\PRAKTIKUM\PAW\praktikum7\resources\views/Tblmahasiswa/index.blade.php ENDPATH**/ ?>